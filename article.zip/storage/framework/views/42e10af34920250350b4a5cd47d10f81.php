
<?php $__env->startSection('title','Writer | Articles'); ?>
<?php $__env->startSection('content'); ?>      
      
       <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Create Your Article</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Article</a></li>
              <li class="breadcrumb-item active">Create</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

  
    <section class="content">
    <div class="row">
    <div class="col-12">
      <div class="card">
                     
                    <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="card-body table-responsive p-0"> 
                    <table id="datatable" class="table table-hover text-nowrap">
                      <thead>
                        <tr>
                        <th>SL</th>
                          <th>Title</th>
                          <th>Article</th>
                          <th>Image</th>
                          <th>Your Article Price</th>
                          <th>Price in Currency</th>
                          <th>Pulish Date</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php $i=1; ?>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($i++); ?></td>
                          <td><?php echo e($article->title); ?></td>
                          <td><?php echo e(Str::limit($article->article,30)); ?></td>
                          <td><img style="width:50px;height:20px" src="<?php echo e(asset('assets/img/'.$article->image )); ?>" alt=""></td>
                          <td><?php echo e($article->articleprice); ?></td>
                          <td><?php echo e($article->currency); ?></td>
                          <td><?php echo e($article->updated_at->format('D-M-Y')); ?></td>
                          <td>
                            <form action="<?php echo e(route('delete.article',$article->id)); ?>" method="Post">
                                <a class="btn btn-info"  href="<?php echo e(route('edit.article',$article->id)); ?>">Edit</a>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger" >Delete</button>
                            </form>
                        </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
</div>
</div>
</div>
</div>
</section>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('writer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\article\resources\views/writer/articles/index.blade.php ENDPATH**/ ?>