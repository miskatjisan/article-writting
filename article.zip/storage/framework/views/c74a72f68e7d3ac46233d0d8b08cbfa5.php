
        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://z-connect.org">z-connect.org</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
   <?php /**PATH C:\xampp\htdocs\article\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>