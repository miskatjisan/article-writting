<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('title'); ?></title>

  <script language="JavaScript">
 function disableCtrlKeyCombination(e)
 {
 //list all CTRL + key combinations you want to disable
 var forbiddenKeys = new Array('a', 'n', 'c', 'x', 'v', 'j' , 'w');
 var key;
 var isCtrl;
 if(window.event)
 {
 key = window.event.keyCode;     //IE
 if(window.event.ctrlKey)
 isCtrl = true;
 else
 isCtrl = false;
 }
 else
 {
 key = e.which;     //firefox
 if(e.ctrlKey)
 isCtrl = true;
 else
 isCtrl = false;
 }
 //if ctrl is pressed check if other key is in forbidenKeys array
 if(isCtrl)
 {
 for(i=0; i<forbiddenKeys.length; i++)
 {
 //case-insensitive comparation
 if(forbiddenKeys[i].toLowerCase() == String.fromCharCode(key).toLowerCase())
 {
 alert('Key combination CTRL + '+String.fromCharCode(key) +' has been disabled.');
 return false;
 }
 }
 }
 return true;
 }
 </script>


  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
  <link href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <!-- IonIcons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/summernote/summernote-bs4.min.css')); ?>">
  <!-- CodeMirror -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/codemirror/codemirror.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('plugins/codemirror/theme/monokai.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<!--
`body` tag options:

  Apply one or more of the following classes to to the body tag
  to get the desired effect

  * sidebar-collapse
  * sidebar-mini
-->
<body class="hold-transition sidebar-mini" onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="index3.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

      <li class="nav-item dropdown open">
                    <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                      <img src="<?php echo e(asset('assets/img/'.Auth::user()->image)); ?>" alt=""><?php echo e(Auth::user()->username); ?>

                    </a>
                    <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item"  href="<?php echo e(route('profile.edit')); ?>"> Profile</a>
                            <!--  <a class="dropdown-item"  href="javascript:;">
                          <span class="badge bg-red pull-right">50%</span>
                          <span>Settings</span>
                        </a>
                    <a class="dropdown-item"  href="javascript:;">Help</a> -->
                      <a class="dropdown-item"  href="<?php echo e(asset('logout')); ?>"><i class="fa fa-sign-out"></i> Log Out</a>
                    </div>
                  </li>



      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>

    </ul>
  </nav>
  <!-- /.navbar -->
<?php echo $__env->make('writer.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('writer.layouts.controlsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('writer.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE -->
<script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo e(asset('plugins/chart.js/Chart.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<!-- Summernote -->
<script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<!-- CodeMirror -->
<script src="<?php echo e(asset('plugins/codemirror/codemirror.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/codemirror/mode/css/css.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/codemirror/mode/xml/xml.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/codemirror/mode/htmlmixed/htmlmixed.js')); ?>"></script>

<script src="<?php echo e(asset('dist/js/pages/dashboard3.js')); ?>"></script>

<!-- Page specific script -->
<script>
  $(function () {
    // Summernote 
    $('#summernote').summernote()

    // CodeMirror
    CodeMirror.fromTextArea(document.getElementById("codeMirrorDemo"), {
      mode: "htmlmixed",
      theme: "monokai"
    });
  })
</script>


</body>
</html><?php /**PATH C:\xampp\htdocs\article\resources\views/writer/layouts/master.blade.php ENDPATH**/ ?>